
    <h1>About Daniel</h1>
    <p>Halo, nama saya <?=$data['nama'];?>, umur saya <?=$data['umur'];?> tahun, saya seorang <?=$data['pekerjaan'];?>. </p>
